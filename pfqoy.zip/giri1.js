class Circle extends Shape() {
  constructor(Shape, x, y, radius) {
    super(Shape, x, y);
    this.radius = radius;
  }
}
class Rectangle extends Shape() {
  constructor(Shape, x, y, width, height) {
    super(Shape, x, y);
    this.width = width;
    this.height = height;
  }
}
