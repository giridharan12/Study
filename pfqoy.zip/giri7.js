var NewMap = new Map();
NewMap.set("name", "giri");
NewMap.set("id", 310616);
NewMap.set("interest", ["c++", "java", "python"]);
NewMap.get("name");
NewMap.get("id");
NewMap.get("interest");
