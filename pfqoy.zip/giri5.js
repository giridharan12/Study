let SumElements = arr => {
  console.log(arr);
  let sum = 0;
  for (let element of arr) {
    sum += element;
  }
  console.log(sum);
};
SumElements([10, 20, 30, 50, 80]);
